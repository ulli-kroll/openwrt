/*
 * Copyright (c) 2021 The Linux Foundation. All rights reserved.
 *
 * Permission to use, copy, modify, and/or distribute this software for
 * any purpose with or without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE
 * AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

/**
 * @file pcie_reg_scratch.h
 *
 * @details the public header file of PCIE scratch register
 */
#ifndef _PCIE_REG_SCRATCH_H_
#define _PCIE_REG_SCRATCH_H_

/*
 * The PCIe scratch register is used for host / target coordination,
 * e.g. for handshaking during certain power transitions.
 * The target writes to the PCIe scratch register, and the host
 * reads from the PCIe scratch register to check when the target
 * has completed an expected action.
 * The host should not write to this register, to avoid the possibility
 * of both the host and target writing this register concurrently and
 * clobbering each other's change.
 */
typedef enum {
    PCIE_SR_SCRATCH_UMAC_OFF   = 0x1,
    PCIE_SR_SCRATCH_UMAC_ON    = 0x2,
    PCIE_SR_SCRATCH_UMAC_FORCE_WAKE = 0x4,
} PCIE_SR_SCRATCH;

/*
 * The WFSS PMM block has 24 contiguous spare registers that can be used
 * as scratch.
 * The target writes to these registers, and the host reads from them.
 * The host should not write to these registers, to avoid the possibility
 * of both the host and target writing this register concurrently and
 * clobbering each other's change.
 *
 * The following enum denotes the purposes of the PMM scratch registers
 * in the target.
 */
typedef enum {
    PMM_SCRATCH_QTIMER_PMM_WLAN_GLOBAL_OFFSET_LO_US,
    PMM_SCRATCH_QTIMER_PMM_WLAN_GLOBAL_OFFSET_HI_US,
    PMM_SCRATCH_MAC0_TSF1_OFFSET_LO_US,
    PMM_SCRATCH_MAC0_TSF1_OFFSET_HI_US,
    PMM_SCRATCH_MAC0_TSF2_OFFSET_LO_US,
    PMM_SCRATCH_MAC0_TSF2_OFFSET_HI_US,
    PMM_SCRATCH_MAC1_TSF1_OFFSET_LO_US,
    PMM_SCRATCH_MAC1_TSF1_OFFSET_HI_US,
    PMM_SCRATCH_MAC1_TSF2_OFFSET_LO_US,
    PMM_SCRATCH_MAC1_TSF2_OFFSET_HI_US,
    PMM_SCRATCH_MLO_OFFSET_LO_US,
    PMM_SCRATCH_MLO_OFFSET_HI_US,
    PMM_SCRATCH_TQM_CLOCK_OFFSET_LO_US,
    PMM_SCRATCH_TQM_CLOCK_OFFSET_HI_US,
    PMM_SCRATCH_Q6_CRASH_REASON,
    PMM_SCRATCH_TWT_OFFSET,
    /** Add PMM scratch registers purposes here */

    PMM_SCRATCH_REG_MAX
} WFSS_PMM_SCRATCH_REG_PURPOSE;
typedef WFSS_PMM_SCRATCH_REG_PURPOSE WFSS_PMM_SCRATCH; /* alias */


#endif /* _PCIE_REG_SCRATCH_H_ */
