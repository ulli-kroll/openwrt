#!/usr/bin/python

import argparse
import sys
import re

def FatalErr(msg):
    print("ERROR: " + msg)
    #assert(False)
    sys.exit(1)

def ParseArgs():
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input-file", dest="in_file",
        help="file containing doxygen-generated HTML",
        type=str,
        default="")
    parser.add_argument("-o", "--output-file", dest="out_file",
        type=str,
        default="")

    options = parser.parse_args()

    if options.in_file == "": FatalErr("Need to specify input file")
    if options.out_file == "": FatalErr("Need to specify output file")
    return options

def FilterContents(contents_in):
    contents_out = []
    header_processed = 0
    footer_processed = 0

    copy = True
    for idx in range(0, len(contents_in)):
        line = contents_in[idx]
        if copy: contents_out.append(line)
        #print("DBG 0: line %d, copy = %s" % (idx, str(copy)))
        if header_processed == 0:
            match = re.search(r'^<!-- end header part -->\s*$', line)
            if match:
                contents_out.append(contents_in[idx+1])
                copy = False
                header_processed = 1
                #print("DBG 1")
        elif header_processed > 0 and header_processed < 3:
            match = re.search(r'^</div>\s*$', line)
            if match:
                header_processed += 1
                #print("DBG 2: %d: %s" % (header_processed, line))
                if header_processed == 3:
                    copy = True
        elif footer_processed == 0:
            match = re.search(r'^<!-- start footer part -->\s*$', line)
            if match:
                copy = False
                footer_processed = 1
        else:
            match = re.search(r'^</div>\s*$', line)
            if match:
                copy = True

    return contents_out

def Main():
    options = ParseArgs()
    fh = open(options.in_file, "r")
    contents = fh.readlines()
    fh.close()

    contents = FilterContents(contents)

    fh = open(options.out_file, "w")
    fh.writelines(contents)
    fh.close()

Main()
