#!/usr/bin/python

import argparse
import re

def FatalErr(msg):
    print("ERROR: " + msg)
    #assert(False)
    sys.exit(1)

def ParseArgs():
    parser = argparse.ArgumentParser()

    parser.add_argument("-H", "--htt-doc-file", dest="htt_file",
        help="file containing doxygen-generated HTML documentation of htt.h",
        type=str,
        default="")
    parser.add_argument("-s", "--htt-stats-doc-file", dest="htt_stats_file",
        help=
            "file containing doxygen-generated HTML " +
            "documentation of htt_stats.h",
        type=str,
        default="")
    parser.add_argument("-o", "--output-file", dest="out_file",
        type=str,
        default="")

    options = parser.parse_args()

    if options.htt_file == "":
        FatalErr("Need to specify htt HTML file")
    if options.htt_stats_file == "":
        FatalErr("Need to specify htt_stats HTML file")
    if options.out_file == "":
        FatalErr("Need to specify output file")
    return options

def ExtractRelevantHttDoc(in_file):
    fh = open(in_file, "r")
    contents = fh.readlines()
    fh.close()

    relevant = []
    relevant.extend([
        "<table class=\"memberdecls\">\n",
        "<tr class=\"heading\"><td colspan=\"2\"><h2 class=\"groupheader\">" +
            "<a name=\"enum-members\"></a>\n",
        "Enumerations</h2></td></tr>\n"])

    ## look for htt_dbg_stats_type enum values list
    #copy = False
    #for idx in range(0, len(contents)):
    #    line = contents[idx]
    #    match = re.search(r'enum.*htt_dbg_stats_type.*\{', line)
    #    if match:
    #        copy = True
    #    if copy: relevant.append(line)
    #    match = re.search(r'^\s*\}</td></tr>\s*$', line)
    #    if copy and match:
    #        break

    # look for htt_stats_tlv_tag_t enum values list
    copy = False
    for idx in range(0, len(contents)):
        line = contents[idx]
        match = re.search(r'enum.*htt_stats_tlv_tag_t.*\{', line)
        if match:
            copy = True
        if copy: relevant.append(line)
        match = re.search(r'^\s*\}</td></tr>\s*$', line)
        if copy and match:
            break

    relevant.append("</table>\n")
    return relevant

def HttStatsDocShuffle(contents):
    extract_start = -1
    extract_end = -1
    insert_at = -1
    for idx in range(0, len(contents)):
        line = contents[idx]
        if extract_start >= 0 and extract_end == -1:
            match = re.search(r'^</table>\s*$', line)
            if match:
                extract_end = idx
        if extract_start == -1:
            match = re.search(r'Enumeration Type Documentation', line)
            if match:
                extract_start = idx
        if insert_at == -1:
            match = re.search(r'^<!-- end header part -->\s*$', line)
            if match:
                insert_at = idx+2
    if extract_start >= 0 and extract_end >= 0 and insert_at >= 0:
        extracted = contents[extract_start:extract_end+1]
        remaining = contents[0:extract_start] + contents[extract_end+1:]
        if insert_at > extract_start: insert_at -= extract_start
        return remaining[0:insert_at] + extracted + remaining[insert_at:]
    else:
        return contents

def UpdateHttStatsDoc(in_file, out_file, doc):
    fh = open(in_file, "r")
    contents = fh.readlines()
    fh.close()

    # move the information from the HTT stats document into the desired order
    contents = HttStatsDocShuffle(contents)

    fixed_doc = [
        "<p>\n",
        "wifistats usage: wifistats &lt stats category &gt <br>\n",
        "Refer to the htt_dbg_ext_stats_type enum " +
            "for the different stats category values.\n",
        "</p>\n",
    ]

    # Find location within contents to insert fixed doc
    for idx in range(0, len(contents)):
        line = contents[idx]
        match = re.search(r'^<!-- end header part -->\s*$', line)
        if match:
            # insert the documentation after the line after the matching line
            contents = contents[0:idx+2] + fixed_doc + contents[idx+2:]
            break
    # Find location within contents to insert doc
    for idx in range(0, len(contents)):
        line = contents[idx]
        match = re.search(r'^<div class.*File Reference', line)
        if match:
            # insert the documentation after the line after the matching line
            contents = contents[0:idx+2] + doc + contents[idx+2:]
            break

    fh = open(out_file, "w")
    fh.writelines(contents)
    fh.close()

def Main():
    options = ParseArgs()
    htt_relevant_doc = ExtractRelevantHttDoc(options.htt_file)
    UpdateHttStatsDoc(
        options.htt_stats_file, options.out_file, htt_relevant_doc)

Main()
