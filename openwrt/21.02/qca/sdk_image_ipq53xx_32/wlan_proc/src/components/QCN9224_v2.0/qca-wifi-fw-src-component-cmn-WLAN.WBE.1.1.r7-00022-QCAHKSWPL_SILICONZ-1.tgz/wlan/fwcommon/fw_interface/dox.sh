
# run doxygen on htt.h file
doxygen htt_dox.cfg && \
# run doxygen on htt_stats.h file
doxygen htt_stats_dox.cfg && \
# post-process doxygen output
cp htt_stats_dox_out/html/doxygen.css doc && \
# beautify the htt__stats_8h.html file produced by doxygen
./dox_html_clean.py -i htt_stats_dox_out/html/htt__stats_8h.html -o doc/htt_stats.html && \
# add relevant pieces from the htt_8h.html file produced by doxygen
./htt_stats_dox_html_postproc.py -H htt_dox_out/html/htt_8h.html -s doc/htt_stats.html -o doc/htt_stats.html

